package Classes;

import java.util.LinkedList;

public class Cliente extends Pessoa
{
    private LinkedList<Venda> HistoricoDeCompras;
}
