package App;

import janela.FrmPrincipal;

public class Main {
    public static void main(String[] args) {

        FrmPrincipal frmPrincipal = new FrmPrincipal();
       }

}
